const mongoose = require('mongoose');

const location = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  age: {
    type: Number,
    required: true,
  },
  mark1: {
    type: Number,
    required: true
  },
  mark2: {
    type: Number,
    required: true
  },
  mark3: {
    type: Number,
    required: true
  }
})
module.exports = mongoose.model('location', location)

                                 //db         //schema value